package com.app.dtos;

public class FoodItemEditDto {

}
