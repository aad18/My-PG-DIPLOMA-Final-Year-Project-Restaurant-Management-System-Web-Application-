package com.app.daos;
//package com.hungerbuzz.daos;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.hungerbuzz.entities.PasswordResetToken;
//
//public interface PasswordResetTokenRepository extends JpaRepository<PasswordResetToken, Integer> {
//	
//	PasswordResetToken findByToken(String token);
//
//}
